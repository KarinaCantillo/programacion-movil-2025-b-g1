import React from 'react';
import './Register.css';

export const Register = () => {
  return (
    <div className="register-container">
      <h2 className="register-title">Registro</h2>
      <input className="register-input" type="text" placeholder="Nombre y apellidos" />
      <input className="register-input" type="tel" placeholder="Telefono" />
      <input className="register-input" type="email" placeholder="Correo" />
      <input className="register-input" type="password" placeholder="Contraseña" />
      <button className="register-button">Registrar</button>
      <div className="back-arrow">←</div>
    </div>
  );
};