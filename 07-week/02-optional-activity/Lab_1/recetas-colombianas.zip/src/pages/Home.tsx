import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';

import React from 'react';
import { Layout } from '../layouts/layout';
import { Register } from '../components/Register';

const Home: React.FC = () => {
 
return <Layout>
<Register/>
</Layout>
 
};

export default Home;
